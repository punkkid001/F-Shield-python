def google(a, b, c):
    if(a>b):
        print("%d > %d"%(a, b))
    elif(b>c):
        print("%d > %d"%(b, c))
    else:
        print("google!")

google(1, 2, 3)
google(3, 2, 1)
google(1, 3, 2)
