print("Hi")

a='google man'
print("Hi %s"%a)

a='facebook'
b='google'
print("Hello %s %s"%(a, b))

a=10
print("Oh number %d"%a)

a=3.14
print("Wow number %f"%a)

print("\t google \n\t facebook")
