a=10
b=1.1
c=True
d=False
e="Hello"
f='Hi'

type(a)
type(b)
type(c)
type(e)
type(f)

2ex=10  #Error
_ex=10

a=10;b=20;c=30;
