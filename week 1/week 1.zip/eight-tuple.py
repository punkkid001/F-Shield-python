tuple_ex=('a', 'b', 'c')
tuple_ex+('d', 'e', 'f')

print(tuple_ex)

tuple_ex*2

print(tuple_ex)
