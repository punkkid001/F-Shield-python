a=0b110
bin(a<<2)

a=0b110
bin(a>>1)

a=0b110
b=0b100
bin(a|b)

a=0b000
bin(~a)

a=0b110
b=0b100
bin(a&b)

a=0b110
b=0b100
bin(a^b)
