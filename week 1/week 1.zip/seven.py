def google():
    print("Love google")

google()

def facebook(num):
    if(num>3):
        print("big number")
    else:
        print("small number")

facebook(4)
facebook(2)

def nate(num):
    return (num*2)

print(nate(3))
