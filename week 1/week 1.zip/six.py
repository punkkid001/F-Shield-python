for i in range(0, 5):
    print("google %d"%i)

for i in range(1, 9):
    for j in range(1, 9):
        print("%d * %d = %d"%(i, j, i*j))

i=0
while(i<10):
    i+=1
    print("google %d"%i)
