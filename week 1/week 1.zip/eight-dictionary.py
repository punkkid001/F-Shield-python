dict_ex={1:'google', 2:'facebook', 3:'gundam'}
dict_ex.values()
dict_ex.keys()
dict_ex.items()
dict_ex.get(2)

print(dict_ex)
dict_ex.clear()
print(dict_ex)

dict_ex={'google':1, 'facebook':2, 'gundam':3}
dict_ex{'google'}

del dict_ex['google']
print(dict_ex)
