list_ex=[1, 2.1, 'google']
list_ex[0]
list_ex.append(5)

print(list_ex)

list_ex.pop(3)
print(list_ex)

list_ex.append(2.1)
print(list_ex)

list_ex.count(2.1)

list_ex=[1,7,3,5,8,2]
list_ex.sort()
print(list_ex)

list_ex.sort(reverse=True)
print(list_ex)

list_ex=[1,6,4,7]
list_ex.remove(6)
print(list_ex)
