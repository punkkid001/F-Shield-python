list_ex={'google', 'facebook', 'naver'}
type(list_ex)

dict_ex={'kakao':1, 'nate':2, 'twitter':3}
type(dict_ex)

tuple_ex=('instagram', 'tumblr', 'soundcloud')
type(tuple_ex)
