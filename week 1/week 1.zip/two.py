a=10
b=20
a+b

a=5.62
b=4.2
a-b

a=3.14
b=4
2*b*a

a=5
b=3
a/b

a=6
b=3
a%b

y=0
if(not y):
    print("GOOGLE")

x=10
y=0
if(x or y):
        print("GOOGLE")

x=10
y=20
if(x and y):
    print("GOOGLE")

a=10
b=20
a>b
a==b
a<=b
a>=b
a!=b

a='google'
b='goo'
a==b
b='google'
a==b

a='facebook'
b='facebook'
id(a)
id(b)
a is b

a='facebook'
b='face'
id(a)
id(b)
a is b
a is not b
