# -*- coding : utf-8 -*-

im_in_module="I'm variable in module."

def printer (content):
    print("Running Printer...")
    print("**** Printing Result ****")
    print(content)
    print("# End of File")

def call_me ():
    print("Hello! Why are you calling me?")
