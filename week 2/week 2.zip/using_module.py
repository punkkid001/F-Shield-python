# -*- coding : utf-8 -*-

import module_ex

variable="I don't like python. \nDo you like python?"

module_ex.printer(variable)

module_ex.call_me()

print(module_ex.im_in_module)
